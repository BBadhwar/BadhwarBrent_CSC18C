// Name: Brent Badhwar
// Date: 04/08/15
// Class: CSC 18C

public class Recursion {
	
	// final value = PV * (1 + i) ^ n
	// PV = present value
	// i = interest rate
	// n = number of years
	
	public static void main(String[] args) {
		
		double pv = 500;
		final double interestRate = .05;
		int numOfYears = 5;
		double finalAmount = 0;
		
		finalAmount = savingsAcc(pv,interestRate,numOfYears);
		System.out.println("Amount saved after " + numOfYears + " Years is: " + "$ " + finalAmount);
	}
	
	public static double savingsAcc(double pv, double interestRate, int numOfYears)
	{
		if (numOfYears == 1)
			return pv * (1 + interestRate);
		else
			return (1 + interestRate) * savingsAcc(pv,interestRate,numOfYears - 1);
	}
	
	
}


