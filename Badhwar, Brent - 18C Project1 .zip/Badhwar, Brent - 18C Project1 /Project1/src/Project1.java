/* 
 * Name: Brent Badhwar
 * Date: 05/20/15
 * Project 1: "Blackjack"
 * Class: CSC-18C
 */

import java.util.Random;
import java.util.Scanner;

public class Project1 {
	
	// Constants:
	static final int DECK_CAPACITY = 52; //standard deck of 52 cards
	static final double PAYOUT_RATE = 1.5; //standard blackjack 3:2 payout
	static final int STARTING_AMOUNT = 20; //player stars with 20 chips
	
	// Using a stack for card deck
	// Using two linked lists for user's and dealer's hand
	static GenericStack<Card> deck = new GenericStack<Card>();
	static GenericLinkedList<Card> user = new GenericLinkedList<Card>();
	static GenericLinkedList<Card> dealer = new GenericLinkedList<Card>();
	
	static double totalPurse; // Total chips
	
	public static void main(String[] args) {
		
		boolean userBust;
		int bet = 0;
		int winner;
		totalPurse = STARTING_AMOUNT;
		initPrompt();
		
		do
		{
			bet = getBet(bet);
			fillDeck();
			getNewHand(user);
			getNewHand(dealer);
			showHands();
			hitOrStay(user);
			userBust = checkForBust(user);
			showHands();
			if (!userBust)
				hit(dealer);
			showHands();
			winner = checkForWinner();
			totalPurse = getPayout(winner,bet);
			clearHandsAndDeck();
		}
		while (totalPurse > 0);
		
		gameOverOutput();
	}
	
	// Determines the payout if user wins
	public static double getPayout(int winner, int bet)
	{
		// if user wins,
		if (winner == 1)
		{
			totalPurse += (int) (bet * PAYOUT_RATE) + bet;
		}
		else if (winner == -1)
		{
			totalPurse -= bet;
		}
		
		return totalPurse;
	}
	
	// Determines winner:
	// returns 1 if user wins,
	// returns 0 if tie
	// returns -1 if user loses, (dealer wins)
	public static int checkForWinner()
	{
		// Conditions that user wins:
		// 1.) if users total is above the dealers and the user 
		// has not busted
		// 2.) if dealer has busted and the user has not busted																									
		if ((getTotal(user) > getTotal(dealer) && !checkForBust(user)) ||
			(checkForBust(dealer)) && !checkForBust(user))
		{
			System.out.println("You won!");
			System.out.println();
			return 1;
		}
		// if user and dealers total are equal it is a tie
		else if (getTotal(user) == getTotal(dealer))
		{
			System.out.println("It's a tie!");
			System.out.println();
			return 0;
		}
		// if user busts or user's total is less than the dealer 
		// user loses
		else
		{
			System.out.println("You lost!");
			if (getTotal(user) > 21)
				System.out.println("User busts!");
			System.out.println();
			return -1;
		}
	}
	
	public static void determineAceVal(GenericLinkedList<Card> hand, int index, String choice)
	{
		// if hand sum is less than 10 without the ace, make the ace value = 11
		// if hand sum is greater than 10, make the ace = 1
		int sum = getTotal(hand) - 1;
		if (sum <= 10 || choice == "S")
		{
			Card card = (Card) hand.getValue(aceExists(hand));
			card.value = card.ace11;
			hand.insertAt(index,card);
			hand.remove(index + 1);
		}
	}
	
	//checks if hand has ace
	//returns index if exists in hand
	//returns -1 if ace is not found in hand
	public static int aceExists(GenericLinkedList<Card> hand)
	{
		for (int i = 0; i < hand.size(); i++)
		{
			 Card card = (Card) hand.getValue(i);
			 if (card.type == "A")
				 return i;
		}
		
		return -1;
	}
	
	// checks to see if hand is a bust (over 21)
	public static boolean checkForBust(GenericLinkedList<Card> hand)
	{
		if (getTotal(hand) > 21)
			return true;
		return false;
	}
	
	// determines whether to hit or stay for 
	// specified hand
	// mutual recursive with hit() function
	public static void hitOrStay(GenericLinkedList<Card> hand)
	{
		Scanner input = new Scanner(System.in);
		String choice = "H";
		boolean bust;
		
		System.out.println("Hit or Stay?");
		System.out.println("Enter H to hit:");
		System.out.println("Enter S to stay:");
		
		bust = checkForBust(hand);
		do
		{
			if (bust)
				break;
			choice = input.nextLine();
			choice = choice.toUpperCase();
		} while (!(choice.equals("H") || choice.equals("S")) && !bust);
		
		if (aceExists(hand) != -1)
			determineAceVal(hand,aceExists(hand),choice);
		
		if (choice.equals("H") && (hand == user) && (getTotal(user) <= 21))
			hit(user);
	}
	
	// adds a card to specified hand
	// mutual recursive with hitOrStay() function
	public static void hit(GenericLinkedList<Card> hand)
	{
		if (hand == user)
		{
			hand.add(deck.pop());
			showHands();
			hitOrStay(hand);
		}
		else if (hand == dealer)
		{
			while (getTotal(dealer) < 17)
			{
				//if ace exists, determine whether
				//it should act as a 1 or 11
				if (aceExists(hand) != -1)
					determineAceVal(hand,aceExists(hand),"H");
				hand.add(deck.pop());
			}
		}
	}
	
	// Returns total of specified hand
	public static int getTotal(GenericLinkedList<Card> hand)
	{
		int sum = 0;
		for (int i = 0; i < hand.size(); i++)
		{
			Card card = (Card) hand.getValue(i);
			sum += card.value;
		}
		
		return sum;
	}
	
	// Displays the user's and dealer's hands
	public static void showHands()
	{
		System.out.println();
		System.out.println("User: ");
		for (int i = 0; i < user.size(); i++)
		{
			Card card = (Card) user.getValue(i);
			System.out.println("" + card.type);
		}
		System.out.println();
		System.out.println("Dealer: ");
		for (int i = 0; i < dealer.size(); i++)
		{
			Card card = (Card) dealer.getValue(i);
			System.out.println("" + card.type);
		}
		System.out.println();
	}
	
	// Get bet value from user
	public static int getBet(int bet)
	{
		System.out.println("Total chips: " + totalPurse);
		System.out.println("Please enter your bet: ");
		Scanner input = new Scanner(System.in);
		do 
		{	//confirming that just numbers are taken in by scanner
			while(!input.hasNextInt())
			    input.next();
			bet = input.nextInt();
			//confirm that bet is a valid value
			if (bet > totalPurse || bet <= 0)
				System.out.println("Invalid bet; Please try again!");
		} while (bet > totalPurse || bet <= 0);
		return bet;
	}
	
	//Initial cards given
	public static void getNewHand(GenericLinkedList<Card> hand)
	{
		if (hand == dealer)
		{
			hand.add(deck.pop());
		}
		else if (hand == user)
		{
			hand.add(deck.pop());
			hand.add(deck.pop());
		}
	}
	
	//Clears all hands and card deck
	public static void clearHandsAndDeck()
	{
		for (int i = 0; i < user.size() + i; i++)
			user.remove(0);
		for (int i = 0; i < dealer.size() + i; i++)
			dealer.remove(0);
		while (deck.pop() != null)
			deck.pop();
	}
	
	// Initializing deck here
	public static void fillDeck()
	{
		Card cardA = new Card("A",1);
		Card card2 = new Card("2",2);
		Card card3 = new Card("3",3);
		Card card4 = new Card("4",4);
		Card card5 = new Card("5",5);
		Card card6 = new Card("6",6);
		Card card7 = new Card("7",7);
		Card card8 = new Card("8",8);
		Card card9 = new Card("9",9);
		Card card10 = new Card("10",10);
		Card cardJ = new Card("J",10);
		Card cardQ = new Card("Q",10);
		Card cardK = new Card("K",10);
		
		Card[] a = new Card[52];
		for (int i = 0; i < 4; i++)
			a[i] = cardA;
		for (int i = 4; i < 8; i++)
			a[i] = card2;
		for (int i = 8; i < 12; i++)
			a[i] = card3;
		for (int i = 12; i < 16; i++)
			a[i] = card4;
		for (int i = 16; i < 20; i++)
			a[i] = card5;
		for (int i = 20; i < 24; i++)
			a[i] = card6;
		for (int i = 24; i < 28; i++)
			a[i] = card7;
		for (int i = 28; i < 32; i++)
			a[i] = card8;
		for (int i = 32; i < 36; i++)
			a[i] = card9;
		for (int i = 36; i < 40; i++)
			a[i] = card10;
		for (int i = 40; i < 44; i++)
			a[i] = cardJ;
		for (int i = 44; i < 48; i++)
			a[i] = cardQ;
		for (int i = 48; i < 52; i++)
			a[i] = cardK;
		
		// Simulating a deck shuffle:
		// Moving each card to a random position within the deck
		for (int i = 0; i < DECK_CAPACITY; i++)
		{	
			Random randNum = new Random();
			int randIndex = randNum.nextInt(51 - 0 + 1);
			Card temp = a[i];
			a[i] = a[randIndex];
			a[randIndex] = temp;
		}
		
		// Adding each card to the actual deck stack
		for (int i = 0; i < DECK_CAPACITY; i++)
			deck.push(a[i]);
	}
	
	public static void initPrompt()
	{
		System.out.println("Welcome to BlackJack!");
		System.out.println();
	}
	
	public static void gameOverOutput()
	{
		System.out.println();
		System.out.println("Sorry, you are out of credits.");
		System.out.println("Thanks for playing!");
	}
}