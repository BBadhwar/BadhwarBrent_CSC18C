import java.util.Arrays;

public class GenericStack <T> {
	
	private T[] array;
	private int size;
	private final int DEFAULT_SIZE = 10;
	public int topIndex;
	
	public GenericStack()
	{
		size = DEFAULT_SIZE;
		array = (T[]) new Object[size];
		topIndex = -1;
	}
	
	public void clear()
	{
		for (int i = 0; i < topIndex + 1; i++)
			pop();
	}
	
	public int getSize()
	{
		return size;
	}
	
	public boolean isFull()
	{
		return (topIndex >= size - 1);
	}
	
	public void push(T obj)
	{	
		topIndex++;
		
		if (isFull())
		{
			size = size * 2;
			array = Arrays.copyOf(array, size);
		}

		array[topIndex] = obj;
	}
	
	public T pop()
	{
		if (topIndex == -1)
			return null;
		
		T top = array[topIndex];
		array[topIndex] = null;
		topIndex--;
		return top;
	}
}
