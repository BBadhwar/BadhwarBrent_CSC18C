
public class Card extends Project1 {
	
	String type;
	int value;
	final int ace11 = 11;
	
	Card(String type, int value)
	{
		this.type = type;
		this.value = value;
	}
	
	Card()
	{
		
	}
}

