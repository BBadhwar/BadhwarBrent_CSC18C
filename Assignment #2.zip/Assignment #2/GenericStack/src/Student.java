
public class Student {
	
	public String name;
	public char grade;
}
