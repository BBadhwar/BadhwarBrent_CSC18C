import java.util.Arrays;

public class GenericStack <T> {
	
	private T[] array;
	private int topIndex;
	private int size;
	private final int DEFAULT_SIZE = 10;
	
	public static void main(String[] args) 
	{
			// Testing for ints:
		
		GenericStack myIntStack = new GenericStack();
		
		System.out.println("For Ints: ");
		
		for (int i = 0; i < 6; i++)
		{
			myIntStack.push(5 * i);
			System.out.println(myIntStack.array[i]);	
		}
		
			//Testing for Students:
		
		GenericStack myStudentStack = new GenericStack();
		
		System.out.println("For Students: ");
		
		Student student1 = new Student();
		Student student2 = new Student();
		
		student1.name = "Roger";
		student1.grade = 'A';
		student2.name = "Al";
		student2.grade = 'B';
		
		myStudentStack.push(student1);
		myStudentStack.push(student2);
		
		Student student3 = new Student();
		Student student4 = new Student();
		
		student3 = (Student) myStudentStack.pop();
		student4 = (Student) myStudentStack.pop();
		
		System.out.println(student3.name);
		System.out.println(student3.grade);
		System.out.println(student4.name);
		System.out.println(student4.grade);
	}
	
	public GenericStack()
	{
		size = DEFAULT_SIZE;
		array = (T[]) new Object[size];
		topIndex = -1;
	}
	
	public int getSize()
	{
		return size;
	}
	
	public boolean isFull()
	{
		return (topIndex >= size - 1);
	}
	
	public void push(T obj)
	{	
		topIndex++;
		
		if (isFull())
		{
			size = size * 2;
			array = Arrays.copyOf(array, size);
		}

		array[topIndex] = obj;
	}
	
	public T pop()
	{
		if (topIndex == -1)
			return null;
		
		T top = array[topIndex];
		array[topIndex] = null;
		topIndex--;
		return top;
	}

	
}
