
public class Employee {
	
	public int empNum;
	public String name;

}
