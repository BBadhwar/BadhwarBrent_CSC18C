public class LinkedStack {
	
	private LinkedList list;

	public static void main(String[] args) {
		
		LinkedStack myStack = new LinkedStack();
		
		System.out.println("Is Empty: " + myStack.isEmpty());
		System.out.println();
		
		System.out.print("Contents:  ");
		for (int i = 0; i < 10; i++)
			myStack.push(i + 1);
		
		myStack.print();
		System.out.println();
		System.out.println("Size: " + myStack.getSize());
		System.out.println("Is Empty: " + myStack.isEmpty());
		System.out.println();
		
		myStack.pop();
		System.out.print("After Pop: ");
		myStack.print();
		System.out.println();
		System.out.println("Size: " + myStack.getSize());
		System.out.println("Is Empty: " + myStack.isEmpty());
	}
	
	public LinkedStack()
	{
		list = new LinkedList();
	}
	
	public int getSize()
	{
		return list.size();
	}
	
	public void print()
	{
		list.print();
	}
	
	public boolean isEmpty()
	{
		return list.isEmpty();
	}
	
	public void push(int num)
	{	
		list.add(num);
	}
	
	public int pop()
	{
		int top = list.getValue(list.size() - 1);
		list.remove(list.size() - 1);
		return top;
	}
	
	public int getValue(int index)
	{
		return list.getValue(index);
	}
}
