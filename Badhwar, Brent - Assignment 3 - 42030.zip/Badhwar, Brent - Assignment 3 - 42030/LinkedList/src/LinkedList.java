public class LinkedList {
	
	public static void main(String[] args) {
        
		LinkedList list = new LinkedList();
 
        for (int i = 0; i < 10; i++) // fill list with values
        	list.add(i + 1);
        
        System.out.print("List: ");
        list.print();
        System.out.println();
        System.out.println("Size: " + list.size());
        System.out.println("Head: " + list.getValue(0));
        System.out.println();
        
        list.remove(1); // removes index 1
        list.remove(6); //removes index 6
        list.insertAt(1, 100); // inserts 100 at index 1
        
        System.out.print("List: ");
        list.print();
        System.out.println();
        System.out.println("Size: " + list.size());
        System.out.println("Head: " + list.getValue(0));
        System.out.println();    
    }
	
	/*
	 * Linked List Class:
	 */
 
    private Node head;
    private int size;
 
    public LinkedList() 
    {
        head = null;
        size = 0;
    }
    
    
    // checkIndex() checks if index is valid when invoking
    // functions that require an index.
    // throws an exception if index is out of bounds.
    public void checkIndex(int index) 
    {
    	if (index < 0 || index > size - 1)
    		throw new ArrayIndexOutOfBoundsException();
    }
    
    public boolean isEmpty()
    {
    	return (head == null);
    }
    
    public void print()
    {
    	for (int i = 0; i < size; i++)
        {
    		System.out.print(getValue(i) + " ");
        }
    }
    
    //gets value at specified index
    public int getValue(int index)
    {
    	checkIndex(index);
    	
    	Node nodePtr = head;
    	for (int i = 0; i < index; i++)
    		nodePtr = nodePtr.next;
    		
    	return nodePtr.data;
    }
 
    //adds to end of list
    public void add(int data)
    {
        Node newNode = new Node(data);
        
        // if list is empty, let head equal the new node 
        if (isEmpty()) 
    	{
    		head = newNode;
    	}
    	else
    	{
    		Node runner = head;
        
    		while (runner.next != null) 
    			runner = runner.next;

    		runner.next = newNode;
    	}
    	
    	size++;
    }
    
    //inserts data at specified index
    public void insertAt(int index, int data)
    {
    	checkIndex(index);
    	
    	Node newNode = new Node(data);
    	Node nodePtr = head;
    	Node previous = new Node();
    	
    	if (index == 0) // change the value of head
    	{
    		Node tempNode = head;
    		head = newNode;
    		head.next = tempNode;
    	}
    	else
    	{
    		for (int i = 0; i < index; i++)
        	{
        		previous = nodePtr;
        		nodePtr = nodePtr.next;
        	}
    		
    		previous.next = newNode;
    		newNode.next = nodePtr;
    	}
    	
    	size++;
    }
    
    // removes value at specified index
    public void remove(int index)
    {
    	checkIndex(index);
    	
    	Node previous = new Node();
    	Node current = head;
    	
    	if (index == 0) // remove head
    	{
    		head = head.next;
    	}
    	else
    	{
    		for (int i = 0; i < index; i++)
    		{
    			previous = current;
    			current = current.next;
    		}
    		
    		previous.next = current.next;
    	}
    	
    	size--;
    }
 
    public int size()
    {
        return size;
    }
    
    /*
     * Node class with its constructors:
     */
 
    private class Node 
    {
    	private int data;
        private Node next;
        
        public Node()
        {
        	next = null;
        }
        
        public Node(int data) 
        {
        	this.data = data;
            next = null;
        }
 
        public Node(int data, Node next) 
        {
        	this.data = data;
            this.next = next;
        }
    }
}
